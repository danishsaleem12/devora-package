Devora logo pack (sample)

SVG for web and print, PNG for slides and documents.
Files ending in -light are for light backgrounds; files ending in -dark come with a navy background for dark layouts.
See devora-brand-guidelines.pdf for clear space and color rules.
